package in.bushansirgur.billingsoftware.io;

public enum PaymentMethod {
    CASH, UPI
}
