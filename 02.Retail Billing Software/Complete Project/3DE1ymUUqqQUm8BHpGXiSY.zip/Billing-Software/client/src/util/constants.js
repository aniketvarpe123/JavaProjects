export const AppConstants = {
    RAZORPAY_KEY_ID: "your_key_id"
}